
let texto = ""
let contador=[]

do {
    texto = (prompt("Ponga algo"))


        contador.push(texto)

}  while (texto != null)
console.log(contador.join(""))